// HelloWorld - corretto.
def main () : Int = {
	writeString("Hello World!");
	return 0;
}