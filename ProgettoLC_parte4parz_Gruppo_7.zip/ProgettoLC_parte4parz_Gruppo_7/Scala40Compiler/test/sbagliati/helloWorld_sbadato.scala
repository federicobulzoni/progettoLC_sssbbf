// HelloWorld sbadato.
def main () : Int = {
	// non ha tipo Int.
	return writeString("Hello World!");
}