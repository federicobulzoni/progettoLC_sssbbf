# Compilatore front-end del linguaggio *Scala40*
## Università degli Studi di Udine - Corso di Linguaggi e Compilatori
  
Il compilatore e tutti i file necessari al suo funzionamento sono presenti nella cartella ```Scala40Compiler```. Quest'ultima contiene un file ```README.md``` che presenta una panoramica su tutto il progetto.

La relazione riguardante il progetto si trova nel file ```ProgettoLC_parte4parz_Gruppo_7_Relazione.pdf```.

### Autori
* Sara Biavaschi (130512)
* Federico Bulzoni (142242)
* Simone Scaboro (143191)